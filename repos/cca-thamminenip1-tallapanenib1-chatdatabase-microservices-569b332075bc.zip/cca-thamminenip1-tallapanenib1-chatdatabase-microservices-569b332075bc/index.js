const express= require('express');
const cors=require('cors');
var bodyParser = require('body-parser');

const app =express()
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
const MongoClient=require('mongodb').MongoClient;


var port=process.env.PORT || 8080;
app.use(cors());
app.use(express.static('/'))
app.listen(port);
console.log("Express starting on port:"+port);
const mongourl = "mongodb+srv://cca-thamminenip1:kanna@cca-thamminenip1.uulfm.mongodb.net/cca-labs?retryWrites=true&w=majority"

    const dbClient = new MongoClient(mongourl,{useNewUrlParser:true,useUnifiedTopology:true});
    dbClient.connect((err)=>{
        if(err) throw err;
        console.log("Connected to the MongoDB cluster");
    });
app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/index.html'); 
});

app.post('/login', function (req, res) {
    let username=req.body.username
    let password=req.body.password
    const db =dbClient.db();
    db.collection("webchatclient").findOne({username:username}).then(results=>{
        console.log(results);
        if(results && results['username']==username && results['password']==password){
            res.json({ code:200,message: 'login successful',username:results["username"],fullname:results["fullname"]})
        }else{
            res.json({code:400,message:"Invalid user"})
        }
    });
    
        
})
app.post('/signup',function (req, res){
        console.log("body of request")
        console.log(req.body);
        let username=req.body.username;
        const db =dbClient.db();
        db.collection("webchatclient").findOne({username:username})
            .then(results=>{
                console.log(results);
                if(results){
                    results.json({ code:400,message: 'User Already Exists' })
                }else{
                    let data={
                        "username":req.body.username,
                        "password":req.body.password,
                        "fullname":req.body.fullName,
                        "email":req.body.email
                    }
                    db.collection("webchatclient").insertOne(data).then(user=>{
                        console.log(user)
                        res.json({ code:200,message: 'Signup Successful! You Can Login Now' })
                    }).catch(err=>{
                        res.json({ code:400,message: err })
                    });
                }
            })
            .catch(err=>{
                res.json({ code:504,message: err });
            });

})
app.post('/newMessage',function(req,res){
    let sender=req.body.sender
    let receiver= req.body.receiver
    let msg=req.body.msg
    const db =dbClient.db();
    let data={
        "sender":req.body.sender,
        "receiver":req.body.receiver,
        "message":req.body.msg
    }
    db.collection("chatdatabse-sprint3").insertOne(data).then(res=>{
        res.json({ code:200,message: 'message sent successfully' })
    }).catch(err=>{
        res.json({ code: 400,err});
    })
})
app.post('/saveMessage', function(req, res) {
    console.log(req.body)
    let sender =req.body.sender
    let receiver=req.body.receiver
    let data={
        sender :req.body.sender,
        receiver:req.body.receiver,
        message:req.body.message,
        timestamp:Date.now()
    }
    if(data.message==null){
        data.message='';
    }
    const db =dbClient.db();
    db.collection("chatdatabse-sprint3").insertOne(data).then(results=>{
        console.log(results);
        res.json({
            "code":200,
            "msg":"inserted"
        })
    }).catch(err=>{
        console.log(err);
        res.json({
            "code":500,
            "msg":"not inserted"
        })
    }); 
})
app.post('/chatbot',function(req,res){

    let msg = req.body.message
    let month = 0
    let day = 0
    if(msg != 'bye'){
        if(msg == 'hello' || msg == 'hey' || msg == 'Hello' || msg == 'Hey'){
            let results = "hey, How may I help you"
            res.json({code:200,chats:results})
        }
        else if(msg == 'How are you?' || msg == 'how are you?'){
            let results = " I am good, How are you?"
            res.json({code:200,chats:results})
        }
        else if(msg == 'good' || msg == 'Good' || msg == "well" || msg == "Well" 
        || msg == "doing well" || msg == " Doing Well" || msg == "doing Well"){
            let results = "Nice, How can I help you?"
            res.json({code:200,chats:results})
        }
        else if(msg == 'who are you?' || msg == 'Who are you?' || msg == 'Who Are You?'){
            let results = "I am a chatbot. I try to answer the questions.Sometimes I get them right. Sometimes I need additional help. How Can I help you today?"
            res.json({code:200,chats:results})
        }else if(msg == 'what are you doing?' || msg == 'What are you doing?' || msg == 'What Are You Doing'){
            let results = "I am helping to you"
            res.json({code:200,chats:results})
        }
        else if(msg == 'How are you doing?'){
            let results = " I am doing well, thank you "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Hey, Whatsup?' || msg == 'hey, whatsup?' || msg == 'Hey, sup?'){
            let results = "Nothing much"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'Hi' || msg == 'hi'){
            let results = "Hello"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'Do you have a time to talk?' || msg == 'do you have a time to talk?'){
            let results = "yes, for you I always have time"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'what is the purpose of life?' || msg == 'What is the Purpose of life?'){
            let results = "To Serve the greater good"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'I am bored' || msg == 'i am bored' || msg == 'I am Bored'){
            let results = "give us the birthday month for checking your personality ? "
            res.json({code:200,chats:results})
        }

        else if(msg == 'can i know my personality check?' || msg == 'Can I know My Personality check?' || msg == 'Can I Know My Personalitycheck?' || msg == 'can i know my personalitycheck?'){
            let results = "yeah sure, can you please provide me the DOB "
            res.json({code:200,chats:results})
        }
        else if(msg == 'January' || msg == 'january' || (month == 1 && day <= 20) || (month == 12 && day >=22)){
            let results =  "Leadership quality is your most impressive quality of these people."
            res.json({code:200,chats:results})
        }
        else if(msg == 'February' || msg == 'february'){
            let results = "You have an unknown charisma around you that attracts others towards you and your ideas"
            res.json({code:200,chats:results})
        }
        else if(msg == 'March' || msg == 'march' || (month == 2 && day >= 19) || (month == 3 && day <= 20)){
            let results = "You are patient, resourceful, productive, and consistent and your personality traits help you to dedicate yourselfselves to a great project."
            res.json({code:200,chats:results})
        }
        else if(msg == 'April' || msg == 'april' || (month == 3 && day >= 21) || (month == 4 && day <= 20)){
            let results = "You are are the task initiators, always first in the line to grab the opportunity."
            res.json({code:200,chats:results})
        }
        else if(msg == 'May' || msg == 'may' || (month == 4 && day >= 21) || (month == 5 && day <= 20) ){
            let results = "You are full of passion and ambition, and this strength of purpose allows you to accomplish a great deal."
            res.json({code:200,chats:results})
        }
        else if(msg == 'June' || msg == 'june' || (month == 5 && day >= 21) || (month == 6 && day <= 20)){
            let results = "You are great at communication. You love to collect and learn about new information'"
            res.json({code:200,chats:results})
        }
        else if(msg == 'July' || msg == 'july' || (month == 6 && day >= 22) || (month == 7 && day <= 22)){
            let results = "You enjoy your home life. You love to be with your families and friends."
            res.json({code:200,chats:results})
        }
        else if(msg == 'August' || msg == 'august' || (month == 7 && day >= 23) || (month == 8 && day <= 23)){
            let results = "You have a great sense of pride and loyalty in their character"
            res.json({code:200,chats:results})
        }
        else if(msg == 'September' || msg == 'september' || (month == 8 && day >= 24) || (month == 9 && day <= 23)){
            let results = "You have mental agility, adaptability, and skillful, meticulous nature."
            res.json({code:200,chats:results})
        }
        else if(msg == 'October' || msg == 'october' || (month == 9 && day >= 24) || (month == 10 && day <= 23)){
            let results = "You have affinity is supporting social connection and exploring the world with grace"
            res.json({code:200,chats:results})
        }
        else if(msg == 'November' || msg == 'november' || (month == 10 && day >= 24) || (month == 11 && day <= 22)){
            let results = "You have intellectual minds and due to this, you are great images"
            res.json({code:200,chats:results})
        }
        else if(msg == 'December' || msg == 'december' || (month == 11 && day >= 23) || (month == 12 && day <= 21)){
            let results = "You are  expansive, affirming, and joyful"
            res.json({code:200,chats:results})
        }
        
        else if(msg == 'Can I Know My Destination?' || msg == 'can i know my destination?' || msg == 'Can I know my destination?'){
            let results = "Yup, Select the type of Weather and also the type whether 'single' or 'couple' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Summer and Single' || msg == 'summer and single'){
            let results = "Your destination is 'Rajasthan, India' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Summer and Couple' || msg == 'summer and couple'){
            let results = "Your destination is 'Cario, Africa' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Winter and Single' || msg == 'winter and single'){
            let results = "Your destination is 'New York, USA' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Winter and Couple' || msg == 'winter and couple'){
            let results = "Your destination is 'Hallstatt, Austria' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Spring and Single' || msg == 'spring and single'){
            let results = "Your destination is 'Atlanta, USA' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'Spring and Couple' || msg == 'spring and couple'){
            let results = "Your destination is 'Maldeevs, India' "
            res.json({code:200,chats:results})
        }
        else if(msg == 'what is the weather at dayton in ohio?' || msg == 'What is the Weather at Dayton in Ohio?' ){
            let results = "Looks kind of cloudy"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'Thank you' || msg == 'thank you' || msg == 'thankyou' || msg == 'Thank You' || msg == 'Thank You'){
            let results = "Anything else"
            res.json({code:200,chats:results})
        } 
        else if(msg == 'nope, thanks' || msg == 'Nope, Thanks'){
            let results = "thank you, have a nice day"
            res.json({code:200,chats:results})
        }
        else if(msg == 'yes' || msg == 'Yes' || msg == 'YES'){
            let results = "Hello, How can I help you?"
            res.json({code:200,chats:results})
        }
        else if(msg == 'no' || msg == 'No' || msg == 'NO'){
            let results = "Please try again!"
            res.json({code:200,chats:results})
        }else{
            let results = "Please contact admin"
            res.json({code:200,chats:results})
        }            
               
    }
    else{
        let results = "Sorry Unable to understand, Do you want to contact the admin ?"
        res.json({code:200,chats:results})
    }
    msg = req.body.message  
//}
//}
    
            

    
});
app.post('/requestMsgs',function (req, res){
        let user1 =req.body.sender
        let user2=req.body.receiver
        const db =dbClient.db();
        db.collection("chatdatabse-sprint3")
        .find({$or:[ {sender:user1, receiver:user2},{sender:user2, receiver:user1}]})
        .sort({timestamp:-1})
        .limit(100)
        .toArray((err,results)=>{
            if(err){
                console.log(err);
                return
            }   
            res.json({code:200,chats:results})
            });
});