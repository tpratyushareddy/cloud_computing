<?php
    echo htmlentities($_REQUEST["data"])
?>
