const express = require('express')
const app = express()
const port = process.env.PORT || 8080;

app.use(express.urlencoded({ extended: false }));

const cors = require('cors');
app.use(cors());

app.listen(port);

app.get('/', (req, res) => {
     res.send('For Destination selection');
});

app.get('/d', (req, res) => {
    let pick = req.query.pick;
    let type = req.query.type;

    let listt = 'None';

    if(pick == 1 && type == 1) {
        listt='Rajasthan, India. ';
    }
    else if(pick == 2 && type == 1) {
        listt = "New York, USA"
    }
    else if(pick == 1 && type == 2) {
        listt = "Cario, Africa"
    }
    else if(pick == 2 && type == 2) {
        listt = "Hallstatt, Austria"
    }
    else if(pick == 3 && type == 1) {
        listt = "Atlanta, USA"
    }
    else if(pick == 3 && type == 2) {
        listt = "Maldeevs, India"
    }

    res.send(listt);

});