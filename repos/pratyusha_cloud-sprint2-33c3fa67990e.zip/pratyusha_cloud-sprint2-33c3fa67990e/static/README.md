# Cloud Computing Sprint 2 Assignment #

By Pratyusha Reddy Thammineni 

ID: 101707053