
## This is Group Project of Cloud Computing and Applications

In this Project, there are 2 members - 

Project Title (Yet to decide)

Member1 is PRATYUSHA REDDY THAMMINENI

Member2 is BHAVYA TULASI TALLAPANENI
