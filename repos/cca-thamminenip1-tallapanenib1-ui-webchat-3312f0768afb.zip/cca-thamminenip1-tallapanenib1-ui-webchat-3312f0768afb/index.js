const express = require('express')
const app = express()
var port = process.env.PORT || 8080;
app.use(express.urlencoded({extended: false}))
const cors = require('cors')
app.use(cors())// New for microservice
app.listen(port)
app.get('/', (req, res) => {
    res.send('Personality Check of the user');
});
app.get('/Personality', (req, res) => {
    let dateOfBirth = req.query.date;

    dateOfBirth = dateOfBirth.split('-');
    let [year, month, day] = dateOfBirth;

    let Personality = 'None';

    if((month == 1 && day <= 20) || (month == 12 && day >=22)) {
        Personality = 'Leadership quality is your most impressive quality of these people.';
    } else if ((month == 1 && day >= 21) || (month == 2 && day <= 18)) {
        Personality = 'You have an unknown charisma around you that attracts others towards you and your ideas';
    } else if((month == 2 && day >= 19) || (month == 3 && day <= 20)) {
        Personality = 'You are patient, resourceful, productive, and consistent and your personality traits help you to dedicate yourselfselves to a great project.';
    } else if((month == 3 && day >= 21) || (month == 4 && day <= 20)) {
        Personality = 'You are are the task initiators, always first in the line to grab the opportunity.';
    } else if((month == 4 && day >= 21) || (month == 5 && day <= 20)) {
        Personality = 'You are full of passion and ambition, and this strength of purpose allows you to accomplish a great deal.';
    } else if((month == 5 && day >= 21) || (month == 6 && day <= 20)) {
        Personality = 'You are great at communication. You love to collect and learn about new information';
    } else if((month == 6 && day >= 22) || (month == 7 && day <= 22)) {
        Personality = 'You enjoy your home life. You love to be with your families and friends.';
    } else if((month == 7 && day >= 23) || (month == 8 && day <= 23)) {
        Personality = 'You have a great sense of pride and loyalty in their character';
    } else if((month == 8 && day >= 24) || (month == 9 && day <= 23)) {
        Personality = 'You have mental agility, adaptability, and skillful, meticulous nature.';
    } else if((month == 9 && day >= 24) || (month == 10 && day <= 23)) {
        Personality = 'You have affinity is supporting social connection and exploring the world with grace';
    } else if((month == 10 && day >= 24) || (month == 11 && day <= 22)) {
        Personality = 'You have intellectual minds and due to this, you are great images';
    } else if((month == 11 && day >= 23) || (month == 12 && day <= 21)) {
        Personality = 'You are  expansive, affirming, and joyful';
    }

    res.send(Personality);

});